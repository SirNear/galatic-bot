const { EmbedBuilder } = require('discord.js');
const Command = require('../../structures/Command');

module.exports = class ajuda extends Command {

	constructor(client) {
		super(client, {
			name: "ajuda",
			category: "util",
			aliases: ["ajuda", 'help', 'comandos','cmds'],
			UserPermission: null,
			clientPermission: null,
			OnlyDevs: false
		})
	}
  
	 run({ message, args, client, server}) {
      		
    const embed = new EmbedBuilder() 
    .setColor('#bc42f4')
    .setTimestamp()
    .setThumbnail(this.client.user.displayAvatarURL())
    .setAuthor({name: `${message.guild.name} | Menu de Ajuda`, iconURL: message.guild.iconURL({ dynamic: true })})	       
    .addFields(
	    {name: `<:7079_rimuru_slime_shocked:810735162286407742> Utilitário | (${this.getCommmandSize("util")})`, value: this.getCategory("util", server.prefix)},
	    {name: `<:3223_ComfyAmongus:810735118615314443> Desenvolvedor | (${this.getCommmandSize("dev")})`, value: this.getCategory("dev", server.prefix)},
	    {name: `<:7992_AmongUs_Investigate:810735122462670869> Moderação | (${this.getCommmandSize("moderation")})`, value: this.getCategory("moderation", server.prefix)},
   	    {name: `<:PeepoPing:810735232918487091> Configuração do Servidor | (${this.getCommmandSize("config")})`, value: this.getCategory("config", server.prefix)},
	    {name: `<:tilapia:811639469199065148> Pokémon | (${this.getCommmandSize("pokemon")})`, value: this.getCategory("pokemon", server.prefix)},
	    {name: `**Convite do Bot**`, value: "[CLIQUE AQUI](https://discord.com/oauth2/authorize?client_id=634216294710771713&scope=bot&permissions=8)"}
     )
     this.client.users.send(message.author.id, {embeds: [embed] }).then(() => {
	message.reply('**Verifique sua DM**')
}).catch((err) => {
	console.log(`Erro no comando 'ajuda': ${err.message}`)
	message.reply('**Erro: Talvez sua DM esteja fechada, pois não consegui lhe enviar mensagem =c**')

})

	}
	
	getCategory(category, prefix) {
		return this.client.commands.filter(c => c.config.category === category).map(c => `\`${prefix}${c.config.name}\``).join(", ")
	}
	
	
	getCommmandSize(category) {
		return this.client.commands.filter(c => c.config.category === category).size
	}

}
