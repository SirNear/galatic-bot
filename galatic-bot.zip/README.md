# Galatic-bot
Um bot de moderação do Discord feito com base em js.
